import { useFocusEffect } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Linking,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import Svg, { Circle, Line } from "react-native-svg";
import { C } from "../../../styles/colors";
import st, { DIFF_COLOR } from "../../../styles/tabs/explore";
import { getIngredients } from "../../store";
import { EC2_ENDPOINTS } from "../../config/api";

function StarRating({ value, size = 12 }) {
  return (
    <Text style={{ fontSize: size, color: "#d97706" }}>
      {"★".repeat(Math.round(value))}{"☆".repeat(5 - Math.round(value))}
    </Text>
  );
}

function RecipeModal({ recipe, onClose }) {
  const [showAllText, setShowAllText] = useState(false);
  const [textReviews, setTextReviews] = useState([]);
  const [youtube,     setYoutube]     = useState(null);

  useEffect(() => {
    if (!recipe) return;
    setTextReviews([]);
    setYoutube(null);
    fetch(`${EC2_ENDPOINTS.recipes}/${recipe.id}`)
      .then(r => r.json())
      .then(data => { setTextReviews(data.reviews || []); })
      .catch(() => {});
    fetch(`${EC2_ENDPOINTS.youtube}?q=${encodeURIComponent(recipe.name)}&recipeId=${recipe.id}`)
      .then(r => r.json())
      .then(videos => { if (videos?.length > 0) setYoutube(videos[0]); })
      .catch(() => {});
  }, [recipe?.id]);

  if (!recipe) return null;
  const diffColor = DIFF_COLOR[recipe.difficulty] || "#888";

  return (
    <Modal visible={!!recipe} transparent animationType="slide" onRequestClose={onClose}>
      <View style={st.modalOverlay}>
        <Pressable style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} onPress={onClose} />
        <View style={st.modalSheet}>
          <View style={st.modalTopBar}>
            <View style={st.modalHandle} />
            <TouchableOpacity style={st.modalCloseBtn} onPress={onClose}>
              <Text style={{ fontSize: 14, color: C.textSub }}>✕</Text>
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={{ padding: 20 }}>
            <View style={st.recipeHeader}>
              <View style={st.recipeEmoji}>
                {recipe.imageUrl
                  ? <Image source={{ uri: recipe.imageUrl }} style={{ width: 64, height: 64, borderRadius: 12 }} resizeMode="cover" />
                  : <Text style={{ fontSize: 40 }}>🍽️</Text>}
              </View>
              <View style={{ flex: 1 }}>
                <View style={st.modalNameRow}>
                  <Text style={[st.recipeName, { marginBottom: 0, flex: 1 }]}>{recipe.name}</Text>
                  <View style={st.modalHeaderRating}>
                    <Text style={{ fontSize: 14 }}>⭐</Text>
                    <Text style={st.modalHeaderRatingText}>{Number(recipe.rating).toFixed(1)}</Text>
                  </View>
                </View>
                <View style={st.badgeRow}>
                  <View style={st.badgeTime}><Text style={st.badgeTimeText}>⏱ {recipe.time}분</Text></View>
                  <View style={[st.badgeDiff, { backgroundColor: diffColor + "20" }]}>
                    <Text style={[st.badgeDiffText, { color: diffColor }]}>{recipe.difficulty}</Text>
                  </View>
                </View>
                <Text style={st.recipeIngr} numberOfLines={2}>
                  {Array.isArray(recipe.ingredients) ? recipe.ingredients.join(" · ") : ""}
                </Text>
              </View>
            </View>

            <View style={st.divider} />

            {Array.isArray(recipe.instructions) && recipe.instructions.length > 0 && (
              <View style={{ paddingVertical: 18 }}>
                <Text style={st.sectionTitle}>조리 과정</Text>
                {recipe.instructions.map((step, i) => (
                  <View key={i} style={st.stepItem}>
                    <View style={st.stepNumber}><Text style={st.stepNumberText}>{i + 1}</Text></View>
                    <Text style={st.stepText}>{step}</Text>
                  </View>
                ))}
              </View>
            )}

            {youtube && (
              <>
                <View style={st.divider} />
                <View style={{ paddingVertical: 18 }}>
                  <Text style={st.sectionTitle}>유튜브 참고</Text>
                  <TouchableOpacity onPress={() => Linking.openURL(youtube.url)}>
                    <View style={{ borderRadius: 10, overflow: "hidden" }}>
                      <Image source={{ uri: youtube.thumbnail }} style={{ width: "100%", height: 180, backgroundColor: "#000" }} resizeMode="cover" />
                      <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, justifyContent: "center", alignItems: "center" }}>
                        <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: "rgba(0,0,0,0.7)", justifyContent: "center", alignItems: "center" }}>
                          <Text style={{ fontSize: 20, color: "#fff" }}>▶</Text>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                  <Text style={st.ytTitle}>{youtube.title}</Text>
                </View>
              </>
            )}

            {textReviews.length > 0 && (
              <View style={{ paddingBottom: 8 }}>
                <View style={st.divider} />
                <View style={[st.reviewTitleRow, { paddingTop: 16 }]}>
                  <Text style={st.sectionTitle}>이용 후기</Text>
                  <View style={st.reviewCountBadge}>
                    <Text style={st.reviewCountText}>{textReviews.length}</Text>
                  </View>
                </View>
                {(showAllText ? textReviews : textReviews.slice(0, 2)).map((rv, i) => (
                  <View key={i} style={st.textReviewItem}>
                    <View style={st.textReviewMeta}>
                      <Text style={st.reviewUser}>{rv.user}</Text>
                      <View style={st.textReviewRightMeta}>
                        <StarRating value={rv.rating} size={11} />
                        <Text style={st.textReviewDate}>{rv.date}</Text>
                      </View>
                    </View>
                    <Text style={st.reviewText}>{rv.text}</Text>
                  </View>
                ))}
                {!showAllText && textReviews.length > 2 && (
                  <TouchableOpacity style={st.reviewMoreBtn} onPress={() => setShowAllText(true)}>
                    <Text style={st.reviewMoreBtnText}>리뷰 더 보기 ({textReviews.length - 2}개)</Text>
                  </TouchableOpacity>
                )}
              </View>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

export default function ExploreScreen() {
  const [allRecipes,     setAllRecipes] = useState([]);
  const [trending,       setTrending]   = useState([]);
  const [categories,     setCategories] = useState(["전체"]);
  const [loading,        setLoading]    = useState(true);
  const [searchLoading,  setSearchLoading] = useState(false);
  const [refreshing,     setRefreshing]    = useState(false);
  const [query,          setQuery]          = useState("");
  const [activeCategory, setCategory]       = useState("전체");
  const [favorites,      setFavorites]      = useState(new Set());
  const [showFavOnly,    setShowFavOnly]    = useState(false);
  const [searchOpen,     setSearchOpen]     = useState(false);
  const [selectedRecipe, setRecipe]         = useState(null);
  const [recoRecipes,    setRecoRecipes]    = useState([]);
  const [filtered,       setFiltered]       = useState([]);

  useEffect(() => {
    Promise.all([
      fetch(EC2_ENDPOINTS.trending).then(r => r.json()),
      fetch(EC2_ENDPOINTS.categories).then(r => r.json()),
    ]).then(([trend, cats]) => {
      setTrending(trend);
      setFiltered(trend);
      setCategories(["전체", ...cats.map(c => c.id)]);
      setRecoRecipes(trend.slice(0, 5));
    }).catch(() => {}).finally(() => setLoading(false));

    // 전체 레시피는 백그라운드에서 로드
    fetch(EC2_ENDPOINTS.recipes)
      .then(r => r.json())
      .then(data => setAllRecipes(data))
      .catch(() => {});
  }, []);

  useFocusEffect(
    useCallback(() => {
      if (!trending.length) return;
      const fridgeSet = new Set(getIngredients().map((n) => n.toLowerCase()));
      if (!fridgeSet.size) { setRecoRecipes(trending.slice(0, 5)); return; }
      const scored = trending
        .map((r) => ({
          ...r,
          matchCount: (r.ingredients || []).filter((ing) => fridgeSet.has(ing.toLowerCase())).length,
        }))
        .filter((r) => r.matchCount > 0)
        .sort((a, b) => b.matchCount - a.matchCount)
        .slice(0, 6);
      setRecoRecipes(scored.length ? scored : trending.slice(0, 5));
    }, [trending])
  );

  useEffect(() => {
    if (!query && activeCategory === "전체" && !showFavOnly) {
      const shuffled = [...trending].sort(() => Math.random() - 0.5).slice(0, 10);
      setFiltered(shuffled);
      return;
    }
    setSearchLoading(true);
    const params = new URLSearchParams();
    if (activeCategory !== "전체") params.set("category", activeCategory);
    if (query.trim()) params.set("search", query.trim());
    fetch(`${EC2_ENDPOINTS.recipes}?${params}`)
      .then(r => r.json())
      .then(data => {
        const result = showFavOnly ? data.filter(r => favorites.has(r.id)) : data;
        setFiltered(result);
      })
      .catch(() => {})
      .finally(() => setSearchLoading(false));
  }, [query, activeCategory, showFavOnly, trending]);

  function shuffle() {
    const pool = allRecipes.length > 0 ? allRecipes : trending;
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, 10);
    setFiltered(shuffled);
    setQuery("");
    setCategory("전체");
    setShowFavOnly(false);
  }

  async function onRefresh() {
    setRefreshing(true);
    shuffle();
    setRefreshing(false);
  }

  function toggleFav(id) {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  if (loading) {
    return (
      <View style={[st.container, { justifyContent: "center", alignItems: "center" }]}>
        <ActivityIndicator size="large" color="#FF6B35" />
      </View>
    );
  }

  return (
    <View style={st.container}>
      <View style={st.header}>
        <View style={st.headerRow}>
          <Text style={st.pageTitle}>레시피 탐색</Text>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Text style={st.resultCount}>{searchLoading ? "..." : `${filtered.length}개`}</Text>
            <TouchableOpacity style={st.headerBtn} onPress={shuffle}>
              <Svg viewBox="0 0 24 24" width={22} height={22} fill="none" stroke={C.textSub} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <Line x1={1} y1={4} x2={1} y2={10} /><Line x1={1} y1={10} x2={7} y2={10} />
                <Line x1={23} y1={20} x2={23} y2={14} /><Line x1={23} y1={14} x2={17} y2={14} />
                <Line x1={20.49} y1={9} x2={21.99} y2={6} /><Line x1={14} y1={3.5} x2={21.99} y2={6} />
                <Line x1={21.99} y1={6} x2={21.99} y2={14} /><Line x1={3.51} y1={15} x2={2.01} y2={18} />
                <Line x1={10} y1={20.5} x2={2.01} y2={18} /><Line x1={2.01} y1={18} x2={2.01} y2={10} />
              </Svg>
            </TouchableOpacity>
            <TouchableOpacity style={st.headerBtn} onPress={() => setSearchOpen(!searchOpen)}>
              <Svg viewBox="0 0 24 24" width={22} height={22} fill="none" stroke={C.textSub} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <Circle cx={11} cy={11} r={8} /><Line x1={21} y1={21} x2={16.65} y2={16.65} />
              </Svg>
            </TouchableOpacity>
          </View>
        </View>
        {searchOpen && (
          <View style={st.searchBar}>
            <Svg viewBox="0 0 24 24" width={17} height={17} fill="none" stroke={C.textMuted} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
              <Circle cx={11} cy={11} r={8} /><Line x1={21} y1={21} x2={16.65} y2={16.65} />
            </Svg>
            <TextInput
              style={st.searchInput} value={query} onChangeText={setQuery}
              placeholder="요리명 또는 재료로 검색" placeholderTextColor={C.textMuted} autoFocus
            />
          </View>
        )}
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={["#FF6B35"]} tintColor="#FF6B35" />}
      >
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingHorizontal: 20, paddingTop: 14, paddingBottom: 2 }}>
          {categories.map((cat) => (
            <TouchableOpacity
              key={cat}
              style={[st.catChip, activeCategory === cat && !showFavOnly && st.catChipActive]}
              onPress={() => { setCategory(cat); setShowFavOnly(false); }}
            >
              <Text style={[st.catChipText, activeCategory === cat && !showFavOnly && st.catChipTextActive]}>{cat}</Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={[st.catChip, showFavOnly && st.catChipFavActive]}
            onPress={() => { setShowFavOnly(!showFavOnly); if (!showFavOnly) setCategory("전체"); }}
          >
            <Text style={[st.catChipText, showFavOnly && st.catChipTextFavActive]}>♡ 즐겨찾기</Text>
          </TouchableOpacity>
        </ScrollView>

        <View style={{ paddingHorizontal: 20, paddingTop: 16 }}>
          <Text style={st.sectionTitleMain}>내 재료로 바로 만드는 요리🍳</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingTop: 10, paddingBottom: 6 }}>
          {recoRecipes.map((r, i) => (
            <TouchableOpacity key={r.id} style={[st.recoCard, { marginLeft: i === 0 ? 20 : 0, marginRight: i === recoRecipes.length - 1 ? 20 : 0 }]} onPress={() => setRecipe(r)}>
              <View style={st.recoVisual}>
                {r.imageUrl
                  ? <Image source={{ uri: r.imageUrl }} style={{ width: 80, height: 80, borderRadius: 10 }} resizeMode="cover" />
                  : <Text style={{ fontSize: 36 }}>🍽️</Text>}
              </View>
              <View style={st.recoInfo}>
                <Text style={st.recoName} numberOfLines={2}>{r.name}</Text>
                <Text style={st.recoMeta}>⭐ {Number(r.rating).toFixed(1)}  ⏱ {r.time}분</Text>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={{ paddingHorizontal: 20, paddingTop: 16 }}>
          <Text style={st.sectionTitleMain}>지금 SNS에서 유행하는 레시피 🔥</Text>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10, paddingTop: 10, paddingBottom: 18 }}>
          {trending.map((recipe, i) => (
            <TouchableOpacity key={recipe.id} style={[st.trendCard, { marginLeft: i === 0 ? 20 : 0, marginRight: i === trending.length - 1 ? 20 : 0 }]} onPress={() => setRecipe(recipe)}>
              <View style={st.trendVisual}>
                <View style={[st.rankBadge, i < 3 && st.rankBadgeTop]}>
                  <Text style={st.rankText}>{i + 1}위</Text>
                </View>
                {recipe.imageUrl
                  ? <Image source={{ uri: recipe.imageUrl }} style={{ width: 70, height: 70, borderRadius: 8 }} resizeMode="cover" />
                  : <Text style={{ fontSize: 40 }}>🍽️</Text>}
                {i < 3 && <Text style={st.flame}>🔥</Text>}
              </View>
              <View style={st.trendInfo}>
                <Text style={st.trendName} numberOfLines={2}>{recipe.name}</Text>
                <View style={st.trendCountBadge}>
                  <Text style={st.trendCountText}>❤️ <Text style={{ fontWeight: "800", color: C.primary }}>{recipe.likes}</Text>명 좋아요</Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={{ paddingHorizontal: 20, gap: 10 }}>
          {searchLoading ? (
            <ActivityIndicator size="small" color="#FF6B35" style={{ marginTop: 20 }} />
          ) : filtered.length === 0 ? (
            <View style={st.emptyState}>
              <Text style={{ fontSize: 52 }}>{showFavOnly ? "🤍" : "🔍"}</Text>
              <Text style={st.emptyTitle}>{showFavOnly ? "즐겨찾기한 레시피가 없어요" : "검색 결과가 없어요"}</Text>
              <Text style={st.emptyDesc}>{showFavOnly ? "레시피의 ♡ 버튼을 눌러 추가해 보세요!" : "다른 키워드로 검색해 보세요"}</Text>
            </View>
          ) : (
            filtered.map((recipe) => (
              <TouchableOpacity key={recipe.id} style={st.recipeCard} onPress={() => setRecipe(recipe)}>
                <View style={st.cardMain}>
                  <View style={st.cardThumb}>
                    {recipe.imageUrl
                      ? <Image source={{ uri: recipe.imageUrl }} style={{ width: "100%", height: "100%", borderRadius: 10 }} resizeMode="cover" />
                      : <Text style={{ fontSize: 28 }}>🍽️</Text>}
                  </View>
                  <View style={st.cardBody}>
                    <View style={st.cardNameRow}>
                      <Text style={st.cardName}>{recipe.name}</Text>
                      <View style={st.cardRating}>
                        <Text style={{ fontSize: 12 }}>⭐</Text>
                        <Text style={st.cardRatingText}>{Number(recipe.rating).toFixed(1)}</Text>
                      </View>
                    </View>
                    <Text style={st.cardIngredients} numberOfLines={1}>
                      {Array.isArray(recipe.ingredients) ? recipe.ingredients.join(", ") : ""}
                    </Text>
                    <View style={st.badgeRow}>
                      <View style={st.badgeTime}><Text style={st.badgeTimeText}>⏱ {recipe.time}분</Text></View>
                      <View style={[st.badgeDiff, { backgroundColor: (DIFF_COLOR[recipe.difficulty] || "#888") + "20" }]}>
                        <Text style={[st.badgeDiffText, { color: DIFF_COLOR[recipe.difficulty] || "#888" }]}>{recipe.difficulty}</Text>
                      </View>
                    </View>
                  </View>
                </View>
                <TouchableOpacity style={[st.heartBtn, favorites.has(recipe.id) && st.heartBtnActive]} onPress={() => toggleFav(recipe.id)}>
                  <Text style={{ fontSize: 18 }}>{favorites.has(recipe.id) ? "❤️" : "🤍"}</Text>
                </TouchableOpacity>
              </TouchableOpacity>
            ))
          )}
        </View>
      </ScrollView>

      <RecipeModal recipe={selectedRecipe} onClose={() => setRecipe(null)} />
    </View>
  );
}
